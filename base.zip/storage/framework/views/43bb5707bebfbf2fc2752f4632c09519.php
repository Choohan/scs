

<!DOCTYPE html>
<html>
    <head>
        <title>Student Counseling Services - TAR UMT Penang Branch</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Tinos:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('css/cfg.css')); ?>" />
    </head>
    <body>
        <div class="full-width-container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </body>
</html>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SCS2\resources\views/layout/guest.blade.php ENDPATH**/ ?>