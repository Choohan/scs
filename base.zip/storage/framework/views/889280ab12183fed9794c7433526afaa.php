
<?php $__env->startSection('content'); ?>
<div class="container-holder">
    <div class="content-50">
        <h1>Welcome back!</h1>
        <h2>Student Counseling Services of TAR UMT Penang Branch</h2>
        <form method="post" action="<?php echo e(route('loginPost')); ?>" id="login-form" name="login-form">
            <?php echo csrf_field(); ?>
            <input type="email" name="email" placeholder="Student's Email*" id="email" />
            <input type="password" name="password" placeholder="Password*" id="password" />
            <input type="submit" value="Login Now" />
        </form>
        <p><a href="<?php echo e(route('register')); ?>">Not registered yet? Create an account now.</a></p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SCS2\resources\views/authentication/login.blade.php ENDPATH**/ ?>