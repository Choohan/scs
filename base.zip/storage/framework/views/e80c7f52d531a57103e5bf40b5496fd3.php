
<?php $__env->startSection('content'); ?>
<div class="container-holder">
    <div class="content-50">
        <h1>Register Now!</h1>
        <h2>Student Counseling Services of TAR UMT Penang Branch</h2>
        <form method="post" action="<?php echo e(route('registerPost')); ?>" id="login-form" name="login-form">
            <?php echo csrf_field(); ?>
            <input type="text" name="full-name" id="full-name" placeholder="Full Name*" required />
            <input type="email" name="email" placeholder="Student's Email*" id="email" required />
            <input type="text" name="studentid" id="studentid" placeholder="Student ID*" required />
            <input type="text" name="contact-no" id="contact-no" placeholder="Contact No*" required />
            <input type="password" name="password" placeholder="Password*" id="password" />
            <input type="password" name="cpassword" placeholder="Confirm Password*" id="cpassword" required />
            <input type="submit" value="Register Now" />
        </form>
        <p><a href="<?php echo e(route('login')); ?>">Registered? Login now!</a></p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SCS2\resources\views/authentication/register.blade.php ENDPATH**/ ?>